// 1
const contentText = document.createElement('h2');
const inputText = document.createElement('input');
document.body.append(contentText,inputText)

inputText.addEventListener('keypress', () => {
       setTimeout(() => {
              contentText.textContent = inputText.value;
       },300)
})

// 2
const addNum = document.createElement("button");
document.body.append(addNum)
addNum.style.height = "60px"
addNum.style.width = "60px"
addNum.textContent = "0"
addNum.onclick = add

function add() {
       addNum.innerHTML = +addNum.innerHTML + 1
}


//3
const square = document.createElement('button')
document.body.append(square)
square.style.height = "60px"
square.style.width = "60px"
square.textContent = "square"
square.onclick = circle

function circle() {
       square.classList.toggle("circle");
}