fetch('https://reqres.in/api/users')
    .then((response) => {
        console.log(response);
        return response.json();
    }).then((body) =>{


        console.log('-----------');
        console.log('Пункт №1:')
        console.log('-----------');
        console.log('body');


        console.log('-----------');
        console.log('Пункт №2:')
        console.log('-----------');
        body.data.forEach(element => {
            console.log(element.last_name)
        });


        console.log('-----------');
        console.log('Пункт №3:');
        console.log('-----------');
        body.data.filter(items => items.lest_name.startWith('W')).forEach(element => {
            console.log(element.last_name)
        });


        console.log('-----------');
        console.log('Пункт №4:');
        console.log('-----------');

        console.log(":")
        body.data.forEach(element => {
            console.log(element.last_name + " " + element.first_name)
        });   
        

        console.log('-----------');
        console.log('Пункт №5:');
        console.log('-----------');

        Object.keys(body.data[0]).forEach(element => console.log(element));

    });