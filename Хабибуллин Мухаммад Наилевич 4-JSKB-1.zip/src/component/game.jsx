import { useState } from "react"

const Game = () => {
    const [heroes,setHeroes] = useState()
    const getData = () =>{
        const options = {
            method: 'GET',
            url: '',
            headers: {
                authorization: '<REQUIRED',
                'X-rapidAPI-Key': '',
                'X-RapidAPI-Host': ''
            }
        };
        fetch('',options)
        .then((res) => res.json())
        .then((res) => console.log(res))
    }
    console.log(heroes)
    return (
        <div>
            <button onClick={getData}>Получить список</button>
        </div>
    )
}

export default Game;
