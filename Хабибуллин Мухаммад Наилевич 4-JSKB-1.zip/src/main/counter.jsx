

import {useEffect, useState} from "react"

const Counter =() =>{
    const [count, setCount] = useState(JSON.parse(window.localStorage.getItem("headerData")));
    useEffect(() =>{
        window.localStorage.setItem("headerData",JSON.stringify(count));
    },[count]
    );

    return(
        <div>
            <div>{count}</div>
            <button onClick={() => setCount(count + 1)}>Прибавить</button>
            <button onClick={() => setCount(count - 1)}>Убавить</button>
        </div>
    )

}

export default Counter;