const Registration = () => {

    return (
        <div classsName= "container">
            <h1 className="h1">Регестрация</h1>
            <form action="#">
                <div className="block">
                    <input type="text" className="input" placeholder="Ф.И.О."/>
                </div>
                <div className="block">
                    <input type="text" className="input" placeholder="Почта"/>
                </div>
                <div className="block">
                    <input type="text" className="input" placeholder="Пороль"/>
                </div>
                <div className="block">
                    <input type="text" className="input" placeholder="Потвердите пороль"/>
                </div>
                <div className="block">
                    <button className="btn">Зарегестрироваться</button>
                </div>
            </form>
        </div>

    )
}

export default Registration;