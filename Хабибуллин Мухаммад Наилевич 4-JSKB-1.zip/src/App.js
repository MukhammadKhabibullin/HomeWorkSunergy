
import './App.css';
import Game from './component/game';
import Registration from './header/registration';
import Main from './main/counter'


function App() {
  return <div>

    <Registration/>
    <Main/>
    <Game/>

  </div>

}

export default App;
